package com.vrdownloader

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore

object ImageUtil {

    // Recorta no centro para a proporção pedida (sem distorcer) e redimensiona
    fun cropScale(src: Bitmap, tw: Int, th: Int): Bitmap {
        val srcRatio = src.width.toFloat() / src.height
        val dstRatio = tw.toFloat() / th
        val cw: Int
        val chh: Int
        if (srcRatio > dstRatio) {
            chh = src.height
            cw = (chh * dstRatio).toInt().coerceIn(1, src.width)
        } else {
            cw = src.width
            chh = (cw / dstRatio).toInt().coerceIn(1, src.height)
        }
        val x = (src.width - cw) / 2
        val y = (src.height - chh) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cw, chh)
        return Bitmap.createScaledBitmap(cropped, tw, th, true)
    }

    // Salva em Downloads/VR360 e devolve o Uri do arquivo
    fun saveJpeg(ctx: Context, bmp: Bitmap, displayName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, "image/jpeg")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/VR360")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Não foi possível criar a thumb em Downloads")
        ctx.contentResolver.openOutputStream(uri)!!.use { o ->
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, o)
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        ctx.contentResolver.update(uri, values, null, null)
        return uri
    }
}
