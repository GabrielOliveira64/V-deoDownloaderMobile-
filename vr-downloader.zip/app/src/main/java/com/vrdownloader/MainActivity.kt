package com.vrdownloader

import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private data class Res(
        val formatId: String,
        val width: Int,
        val height: Int,
        val fps: Int,
        val codec: String
    )

    private lateinit var urlInput: TextInputEditText
    private lateinit var loading: CircularProgressIndicator
    private lateinit var infoCard: MaterialCardView
    private lateinit var thumb: ImageView
    private lateinit var titleView: TextView
    private lateinit var durationView: TextView
    private lateinit var resLabel: TextView
    private lateinit var chipGroup: ChipGroup
    private lateinit var resInfo: TextView
    private lateinit var downloadBtn: MaterialButton
    private lateinit var progress: LinearProgressIndicator
    private lateinit var status: TextView

    private val initDone = CompletableDeferred<Boolean>()
    private var fetchJob: Job? = null
    private var resolutions: List<Res> = emptyList()
    private var selected: Res? = null
    private var videoTitle = "video"
    private var busy = false
    private val dlDir by lazy { File(cacheDir, "dl") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        loading = findViewById(R.id.loading)
        infoCard = findViewById(R.id.infoCard)
        thumb = findViewById(R.id.thumb)
        titleView = findViewById(R.id.titleView)
        durationView = findViewById(R.id.durationView)
        resLabel = findViewById(R.id.resLabel)
        chipGroup = findViewById(R.id.chipGroup)
        resInfo = findViewById(R.id.resInfo)
        downloadBtn = findViewById(R.id.downloadBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        status.text = "Preparando o motor de download (na primeira vez demora um pouco)…"
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                    null
                } catch (e: Exception) {
                    e.message ?: "erro desconhecido"
                }
            }
            if (err == null) {
                status.text = ""
                initDone.complete(true)
            } else {
                status.text = "Falha ao iniciar: $err"
                initDone.complete(false)
            }
        }

        urlInput.doAfterTextChanged { text ->
            fetchJob?.cancel()
            val url = text?.toString()?.trim().orEmpty()
            fetchJob = lifecycleScope.launch {
                delay(500)
                fetchInfo(url)
            }
        }

        chipGroup.setOnCheckedStateChangeListener { group, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            val idx = group.findViewById<Chip>(id)?.tag as? Int ?: return@setOnCheckedStateChangeListener
            selected = resolutions.getOrNull(idx)
            updateResInfo()
            updateButton()
        }

        downloadBtn.setOnClickListener { startDownload() }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val u = Regex("""https?://\S+""").find(t)?.value ?: t
            urlInput.setText(u)
        }
    }

    // ---------- Busca de informações ----------

    private fun resetInfoUi() {
        loading.visibility = View.GONE
        infoCard.visibility = View.GONE
        resLabel.visibility = View.GONE
        chipGroup.visibility = View.GONE
        resInfo.visibility = View.GONE
        resolutions = emptyList()
        selected = null
        updateButton()
    }

    private suspend fun fetchInfo(url: String) {
        resetInfoUi()
        if (url.isEmpty()) {
            if (!busy) status.text = ""
            return
        }
        if (!Regex("""(youtube\.com|youtu\.be)/""", RegexOption.IGNORE_CASE).containsMatchIn(url)) {
            status.text = "Cole um link válido do YouTube."
            return
        }
        loading.visibility = View.VISIBLE
        status.text = "Buscando informações…"
        if (!initDone.await()) {
            loading.visibility = View.GONE
            return
        }
        try {
            val info = withContext(Dispatchers.IO) {
                val r = YoutubeDLRequest(url)
                r.addOption("--no-playlist")
                YoutubeDL.getInstance().getInfo(r)
            }

            videoTitle = info.title ?: "video"
            titleView.text = videoTitle
            durationView.text = "Duração: " + formatDuration((info.duration ?: 0).toInt())

            val all = (info.formats ?: emptyList()).mapNotNull { f ->
                val id = f.formatId ?: return@mapNotNull null
                val vc = f.vcodec ?: "none"
                val w = (f.width ?: 0).toInt()
                val h = (f.height ?: 0).toInt()
                val fps = (f.fps ?: 0).toInt()
                if (vc == "none" || w <= 0 || h <= 0) null else Res(id, w, h, fps, vc)
            }
            // Para cada resolução, escolhe o melhor formato (mais fps; depois codec mais compatível)
            val list = all
                .groupBy { it.width to it.height }
                .map { (_, g) ->
                    g.sortedWith(compareByDescending<Res> { it.fps }.thenBy { codecRank(it.codec) }).first()
                }
                .sortedByDescending { it.width.toLong() * it.height }

            if (list.isEmpty()) {
                loading.visibility = View.GONE
                status.text = "Nenhum formato de vídeo encontrado."
                return
            }

            resolutions = list
            buildChips()
            infoCard.visibility = View.VISIBLE
            resLabel.visibility = View.VISIBLE
            chipGroup.visibility = View.VISIBLE
            resInfo.visibility = View.VISIBLE
            loading.visibility = View.GONE
            status.text = ""

            val thumbUrl = info.thumbnail
            if (!thumbUrl.isNullOrEmpty()) {
                val bmp = withContext(Dispatchers.IO) {
                    runCatching { URL(thumbUrl).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
                }
                if (bmp != null) thumb.setImageBitmap(bmp)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            loading.visibility = View.GONE
            status.text = "Erro ao buscar o vídeo: ${e.message?.take(200)}"
        }
    }

    private fun codecRank(c: String): Int = when {
        c.startsWith("avc1") -> 0
        c.startsWith("vp09") || c.startsWith("vp9") -> 1
        c.startsWith("av01") -> 2
        else -> 3
    }

    private fun buildChips() {
        chipGroup.removeAllViews()
        resolutions.forEachIndexed { idx, r ->
            val chip = layoutInflater.inflate(R.layout.chip_res, chipGroup, false) as Chip
            chip.id = View.generateViewId()
            chip.tag = idx
            chip.text = "${r.width}×${r.height}" + if (r.fps > 0) " · ${r.fps}fps" else ""
            chipGroup.addView(chip)
        }
        // Seleciona automaticamente a maior resolução (primeira da lista)
        (chipGroup.getChildAt(0) as? Chip)?.let {
            chipGroup.check(it.id)
        }
        selected = resolutions.firstOrNull()
        updateResInfo()
        updateButton()
    }

    private fun updateResInfo() {
        val r = selected ?: return
        val ratio = r.width.toFloat() / r.height
        val ratioTxt = if (abs(ratio - 2f) < 0.02f) "2:1 (360° equiretangular)" else String.format("%.2f:1", ratio)
        resInfo.text = "Original: ${r.width}×${r.height} · proporção $ratioTxt · ${r.codec.substringBefore('.')}"
    }

    private fun updateButton() {
        downloadBtn.isEnabled = selected != null && !busy
    }

    // ---------- Download ----------

    private fun startDownload() {
        val res = selected ?: return
        val url = urlInput.text?.toString()?.trim().orEmpty()
        busy = true
        updateButton()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        progress.isIndeterminate = false
        progress.setProgressCompat(0, false)
        progress.visibility = View.VISIBLE
        status.text = "Baixando… (mantenha o app aberto)"

        lifecycleScope.launch {
            try {
                val finalName = withContext(Dispatchers.IO) {
                    dlDir.deleteRecursively()
                    dlDir.mkdirs()

                    val req = YoutubeDLRequest(url)
                    req.addOption("--no-playlist")
                    // Formato exato escolhido (resolução original) + melhor áudio
                    req.addOption(
                        "-f",
                        "${res.formatId}+ba[ext=m4a]/${res.formatId}+ba/${res.formatId}"
                    )
                    req.addOption("--merge-output-format", "mp4")
                    req.addOption("--no-mtime")
                    req.addOption("-o", dlDir.absolutePath + "/%(id)s.%(ext)s")

                    YoutubeDL.getInstance().execute(req, "vr-download") { p, _, line ->
                        runOnUiThread {
                            if (line.contains("[Merger]") || line.contains("Merging")) {
                                status.text = "Mesclando vídeo e áudio…"
                            } else if (p >= 0f) {
                                progress.setProgressCompat(p.toInt().coerceIn(0, 100), true)
                                status.text = "Baixando… ${p.toInt()}%"
                            }
                        }
                    }

                    val file = dlDir.listFiles()
                        ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                        ?.maxByOrNull { it.length() }
                        ?: throw IllegalStateException("Arquivo final não encontrado")

                    val name = safeName(videoTitle) + " ${res.width}x${res.height}." + file.extension
                    saveToDownloads(file, name)
                    file.delete()
                    name
                }
                progress.setProgressCompat(100, false)
                status.text = "Concluído!\nSalvo em Downloads/VR360/$finalName"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = "Erro no download: ${e.message?.take(300)}"
                progress.visibility = View.GONE
            } finally {
                busy = false
                updateButton()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    private fun saveToDownloads(file: File, displayName: String) {
        val mime = when (file.extension.lowercase()) {
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            else -> "video/mp4"
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/VR360")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Não foi possível criar o arquivo em Downloads")
        contentResolver.openOutputStream(uri)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
    }

    private fun safeName(s: String): String =
        s.replace(Regex("""[\\/:*?"<>|\r\n\t]"""), "_").trim().take(80).ifEmpty { "video" }

    private fun formatDuration(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
    }
}
