package com.vrdownloader

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputEditText
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.lang.reflect.Modifier
import java.net.URL
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private data class Res(
        val formatId: String,
        val width: Int,
        val height: Int,
        val fps: Int,
        val codec: String
    )

    private data class ThumbSpec(val w: Int, val h: Int)

    private lateinit var tabs: TabLayout
    private lateinit var storeTab: StoreTab
    private lateinit var libraryTab: LibraryTab
    private var thumbOriginal: Bitmap? = null

    private lateinit var urlInput: TextInputEditText
    private lateinit var loading: CircularProgressIndicator
    private lateinit var infoCard: MaterialCardView
    private lateinit var thumb: ImageView
    private lateinit var titleView: TextView
    private lateinit var durationView: TextView
    private lateinit var resLabel: TextView
    private lateinit var chipGroup: ChipGroup
    private lateinit var resInfo: TextView
    private lateinit var downloadBtn: MaterialButton
    private lateinit var progress: LinearProgressIndicator
    private lateinit var status: TextView

    private val initDone = CompletableDeferred<Boolean>()
    private var fetchJob: Job? = null
    private var resolutions: List<Res> = emptyList()
    private var selected: Res? = null
    private var videoTitle = "video"
    private var busy = false
    private val dlDir by lazy { File(cacheDir, "dl") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        loading = findViewById(R.id.loading)
        infoCard = findViewById(R.id.infoCard)
        thumb = findViewById(R.id.thumb)
        titleView = findViewById(R.id.titleView)
        durationView = findViewById(R.id.durationView)
        resLabel = findViewById(R.id.resLabel)
        chipGroup = findViewById(R.id.chipGroup)
        resInfo = findViewById(R.id.resInfo)
        downloadBtn = findViewById(R.id.downloadBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        tabs = findViewById(R.id.tabs)
        val downloadRoot = findViewById<View>(R.id.downloadRoot)
        val storeRoot = findViewById<View>(R.id.storeRoot)
        val libraryRoot = findViewById<View>(R.id.libraryRoot)
        tabs.addTab(tabs.newTab().setText("Baixar"))
        tabs.addTab(tabs.newTab().setText("Enviar"))
        tabs.addTab(tabs.newTab().setText("Biblioteca"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                downloadRoot.visibility = if (tab.position == 0) View.VISIBLE else View.GONE
                storeRoot.visibility = if (tab.position == 1) View.VISIBLE else View.GONE
                libraryRoot.visibility = if (tab.position == 2) View.VISIBLE else View.GONE
                if (tab.position == 2) libraryTab.onShown()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        storeTab = StoreTab(this)
        libraryTab = LibraryTab(this, storeTab)

        status.setTextIsSelectable(true)
        status.text = "Preparando e atualizando o motor de download (pode demorar um pouco)…"
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                    updateYtDlpIfNeeded()
                    null
                } catch (e: Exception) {
                    e.message ?: "erro desconhecido"
                }
            }
            if (err == null) {
                status.text = ""
                initDone.complete(true)
            } else {
                status.text = "Falha ao iniciar: $err"
                initDone.complete(false)
            }
        }

        urlInput.doAfterTextChanged { text ->
            fetchJob?.cancel()
            val url = text?.toString()?.trim().orEmpty()
            fetchJob = lifecycleScope.launch {
                delay(500)
                fetchInfo(url)
            }
        }

        chipGroup.setOnCheckedStateChangeListener { group, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            val idx = group.findViewById<Chip>(id)?.tag as? Int ?: return@setOnCheckedStateChangeListener
            selected = resolutions.getOrNull(idx)
            updateResInfo()
            updateButton()
        }

        downloadBtn.setOnClickListener { askThumbThenDownload() }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val u = Regex("""https?://\S+""").find(t)?.value ?: t
            tabs.getTabAt(0)?.select()
            urlInput.setText(u)
        }
    }

    // ---------- Busca de informações ----------

    private fun resetInfoUi() {
        loading.visibility = View.GONE
        infoCard.visibility = View.GONE
        resLabel.visibility = View.GONE
        chipGroup.visibility = View.GONE
        resInfo.visibility = View.GONE
        resolutions = emptyList()
        selected = null
        thumbOriginal = null
        updateButton()
    }

    private suspend fun fetchInfo(url: String) {
        resetInfoUi()
        if (url.isEmpty()) {
            if (!busy) status.text = ""
            return
        }
        if (!Regex("""(youtube\.com|youtu\.be)/""", RegexOption.IGNORE_CASE).containsMatchIn(url)) {
            status.text = "Cole um link válido do YouTube."
            return
        }
        loading.visibility = View.VISIBLE
        status.text = "Buscando informações…"
        if (!initDone.await()) {
            loading.visibility = View.GONE
            return
        }
        try {
            val info = withContext(Dispatchers.IO) {
                val r = YoutubeDLRequest(url)
                r.addOption("--no-playlist")
                YoutubeDL.getInstance().getInfo(r)
            }

            videoTitle = info.title ?: "video"
            titleView.text = videoTitle
            durationView.text = "Duração: " + formatDuration((info.duration ?: 0).toInt())

            val all = (info.formats ?: emptyList()).mapNotNull { f ->
                val id = f.formatId ?: return@mapNotNull null
                val vc = f.vcodec ?: "none"
                val w = (f.width ?: 0).toInt()
                val h = (f.height ?: 0).toInt()
                val fps = (f.fps ?: 0).toInt()
                if (vc == "none" || w <= 0 || h <= 0) null else Res(id, w, h, fps, vc)
            }
            // Para cada resolução, escolhe o melhor formato (mais fps; depois codec mais compatível)
            val list = all
                .groupBy { it.width to it.height }
                .map { (_, g) ->
                    g.sortedWith(compareByDescending<Res> { it.fps }.thenBy { codecRank(it.codec) }).first()
                }
                .sortedByDescending { it.width.toLong() * it.height }

            if (list.isEmpty()) {
                loading.visibility = View.GONE
                status.text = "Nenhum formato de vídeo encontrado."
                return
            }

            resolutions = list
            val autoNote = buildChips()
            infoCard.visibility = View.VISIBLE
            resLabel.visibility = View.VISIBLE
            chipGroup.visibility = View.VISIBLE
            resInfo.visibility = View.VISIBLE
            loading.visibility = View.GONE
            status.text = autoNote ?: ""

            val thumbUrl = info.thumbnail
            if (!thumbUrl.isNullOrEmpty()) {
                val bmp = withContext(Dispatchers.IO) {
                    runCatching { URL(thumbUrl).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
                }
                if (bmp != null) {
                    thumb.setImageBitmap(bmp)
                    thumbOriginal = bmp
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            loading.visibility = View.GONE
            status.text = "Erro ao buscar o vídeo: ${e.message?.take(200)}"
        }
    }

    private fun codecRank(c: String): Int = when {
        c.startsWith("avc1") -> 0
        c.startsWith("vp09") || c.startsWith("vp9") -> 1
        c.startsWith("av01") -> 2
        else -> 3
    }

    // 2 = decodificador de hardware, 1 = só por software (pode travar), 0 = nenhum
    private fun decodeSupport(r: Res): Int {
        val mime = when {
            r.codec.startsWith("avc1") -> "video/avc"
            r.codec.startsWith("vp09") || r.codec.startsWith("vp9") -> "video/x-vnd.on2.vp9"
            r.codec.startsWith("av01") -> "video/av01"
            r.codec.startsWith("hvc1") || r.codec.startsWith("hev1") -> "video/hevc"
            else -> return 2
        }
        return try {
            var best = 0
            val fps = if (r.fps > 0) r.fps.toDouble() else 30.0
            for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
                if (info.isEncoder) continue
                if (!info.supportedTypes.any { it.equals(mime, ignoreCase = true) }) continue
                val vc = info.getCapabilitiesForType(mime).videoCapabilities ?: continue
                if (vc.areSizeAndRateSupported(r.width, r.height, fps)) {
                    best = maxOf(best, if (info.isHardwareAccelerated) 2 else 1)
                }
            }
            best
        } catch (e: Exception) {
            2
        }
    }

    private fun codecTag(c: String): String = when {
        c.startsWith("avc1") -> "H.264"
        c.startsWith("vp09") || c.startsWith("vp9") -> "VP9"
        c.startsWith("av01") -> "AV1"
        c.startsWith("hvc1") || c.startsWith("hev1") -> "H.265"
        else -> c.substringBefore('.')
    }

    private fun buildChips(): String? {
        chipGroup.removeAllViews()
        val sup = resolutions.map { decodeSupport(it) }
        resolutions.forEachIndexed { idx, r ->
            val chip = layoutInflater.inflate(R.layout.chip_res, chipGroup, false) as Chip
            chip.id = View.generateViewId()
            chip.tag = idx
            val mark = when (sup[idx]) {
                0 -> " ⛔"
                1 -> " ⚠"
                else -> ""
            }
            chip.text = "${r.width}×${r.height}" + (if (r.fps > 0) " · ${r.fps}fps" else "") +
                " · " + codecTag(r.codec) + mark
            chipGroup.addView(chip)
        }
        // Seleciona automaticamente a maior resolução que ESTE aparelho consegue reproduzir
        // com decodificador de hardware (se nenhuma, a maior com decodificador por software)
        var pick = sup.indexOf(2)
        if (pick < 0) pick = sup.indexOf(1)
        if (pick < 0) pick = 0
        (chipGroup.getChildAt(pick) as? Chip)?.let {
            chipGroup.check(it.id)
        }
        selected = resolutions.getOrNull(pick)
        updateResInfo()
        updateButton()
        if (pick > 0) {
            val top = resolutions[0]
            val sel = resolutions[pick]
            return "A maior resolução (${top.width}×${top.height}, ${codecTag(top.codec)}) não é " +
                "reproduzida direito por este aparelho (pode abrir só com áudio ou travar). " +
                "Selecionei ${sel.width}×${sel.height}. Você pode escolher outra."
        }
        return null
    }

    private fun updateResInfo() {
        val r = selected ?: return
        val ratio = r.width.toFloat() / r.height
        val ratioTxt = if (abs(ratio - 2f) < 0.02f) "2:1 (360° equiretangular)" else String.format("%.2f:1", ratio)
        val tag = codecTag(r.codec)
        val warn = when (decodeSupport(r)) {
            1 -> "\n⚠ Sem decodificador de hardware para $tag neste aparelho: pode tocar só o áudio ou travar."
            0 -> "\n⛔ Este aparelho não decodifica $tag nesta resolução: só o áudio vai tocar."
            else -> ""
        }
        resInfo.text = "Original: ${r.width}×${r.height} · proporção $ratioTxt · $tag$warn"
    }

    private fun updateButton() {
        downloadBtn.isEnabled = selected != null && !busy
    }

    // ---------- Atualização do yt-dlp ----------

    private fun updateYtDlpIfNeeded() {
        val prefs = getSharedPreferences("ytdlp", MODE_PRIVATE)
        val last = prefs.getLong("last_update", 0L)
        if (System.currentTimeMillis() - last < 6 * 3600 * 1000L) return
        if (updateYtDlp()) prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
    }

    // Usa reflexão para funcionar independente da forma como a biblioteca expõe o "canal" de update
    private fun updateYtDlp(): Boolean {
        return try {
            val yd = YoutubeDL.getInstance()
            val m = yd.javaClass.methods.first { it.name == "updateYoutubeDL" && it.parameterTypes.size == 2 }
            val chType = m.parameterTypes[1]
            for (n in listOf("_NIGHTLY", "NIGHTLY", "_STABLE", "STABLE")) {
                val ch = findChannel(chType, n) ?: continue
                try {
                    m.invoke(yd, applicationContext, ch)
                    return true
                } catch (_: Exception) {
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun findChannel(type: Class<*>, name: String): Any? {
        type.declaredFields.firstOrNull { it.name == name && Modifier.isStatic(it.modifiers) }?.let {
            it.isAccessible = true
            return it.get(null)
        }
        type.declaredClasses.firstOrNull { it.simpleName == name }?.let { c ->
            val f = c.getDeclaredField("INSTANCE")
            f.isAccessible = true
            return f.get(null)
        }
        return null
    }

    private fun cleanError(msg: String?): String {
        val lines = msg.orEmpty().lines().map { it.trim() }.filter {
            it.isNotEmpty() &&
                !it.contains("older than") &&
                !it.startsWith("It is strongly") &&
                !it.startsWith("Run \"yt-dlp") &&
                !it.startsWith("To suppress")
        }
        val errors = lines.filter { it.startsWith("ERROR") }
        return (if (errors.isNotEmpty()) errors.takeLast(2) else lines.takeLast(4)).joinToString("\n").take(700)
    }

    // Confere se o Android enxerga a faixa de vídeo e consegue decodificar um quadro
    private fun verifyPlayable(f: File): String {
        try {
            var hasVideo = false
            val ex = MediaExtractor()
            try {
                ex.setDataSource(f.absolutePath)
                for (i in 0 until ex.trackCount) {
                    val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                    if (m.startsWith("video/")) hasVideo = true
                }
            } finally {
                ex.release()
            }
            if (!hasVideo) {
                return "⚠ O Android não enxerga a faixa de vídeo deste arquivo (codec/container não suportado). " +
                    "Ele pode tocar só o áudio. Tente uma resolução em H.264."
            }
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.absolutePath)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val frame = r.getFrameAtTime(dur * 500L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame == null) {
                    return "⚠ Este aparelho não conseguiu decodificar o vídeo. Ele pode tocar só o áudio. " +
                        "Tente uma resolução em H.264."
                }
                frame.recycle()
            } finally {
                r.release()
            }
            return "✔ Verificado: este aparelho decodifica o vídeo."
        } catch (e: Exception) {
            return "⚠ Não consegui verificar a reprodução: " + e.message
        }
    }

    // ---------- Thumb ----------

    private fun askThumbThenDownload() {
        val view = layoutInflater.inflate(R.layout.dialog_thumb, null)
        val group = view.findViewById<RadioGroup>(R.id.thumbGroup)
        val customRow = view.findViewById<View>(R.id.customRow)
        val cw = view.findViewById<TextInputEditText>(R.id.customW)
        val ch = view.findViewById<TextInputEditText>(R.id.customH)
        group.setOnCheckedChangeListener { _, id ->
            customRow.visibility = if (id == R.id.rbCustom) View.VISIBLE else View.GONE
        }
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Baixar também a thumb do vídeo?")
            .setView(view)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Baixar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var spec: ThumbSpec? = null
                when (group.checkedRadioButtonId) {
                    R.id.rbNone -> spec = null
                    R.id.rb320 -> spec = ThumbSpec(320, 160)
                    R.id.rb640 -> spec = ThumbSpec(640, 320)
                    R.id.rb1280 -> spec = ThumbSpec(1280, 640)
                    R.id.rbOrig -> spec = ThumbSpec(0, 0)
                    R.id.rbCustom -> {
                        val w = cw.text?.toString()?.toIntOrNull() ?: 0
                        val h = ch.text?.toString()?.toIntOrNull() ?: 0
                        if (w < 16 || h < 16 || w > 4096 || h > 4096) {
                            cw.error = "Use valores entre 16 e 4096"
                            return@setOnClickListener
                        }
                        spec = ThumbSpec(w, h)
                    }
                }
                dialog.dismiss()
                startDownload(spec)
            }
        }
        dialog.show()
    }

    // Recorta no centro para a proporção pedida (sem distorcer) e redimensiona
    private fun cropScale(src: Bitmap, tw: Int, th: Int): Bitmap {
        val srcRatio = src.width.toFloat() / src.height
        val dstRatio = tw.toFloat() / th
        val cw: Int
        val chh: Int
        if (srcRatio > dstRatio) {
            chh = src.height
            cw = (chh * dstRatio).toInt().coerceIn(1, src.width)
        } else {
            cw = src.width
            chh = (cw / dstRatio).toInt().coerceIn(1, src.height)
        }
        val x = (src.width - cw) / 2
        val y = (src.height - chh) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cw, chh)
        return Bitmap.createScaledBitmap(cropped, tw, th, true)
    }

    private fun saveThumb(src: Bitmap, spec: ThumbSpec): String {
        val out = if (spec.w <= 0 || spec.h <= 0) src else cropScale(src, spec.w, spec.h)
        val name = safeName(videoTitle).replace(' ', '_') + "_thumb.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "image/jpeg")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/VR360")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Não foi possível criar a thumb em Downloads")
        contentResolver.openOutputStream(uri)!!.use { o ->
            out.compress(Bitmap.CompressFormat.JPEG, 92, o)
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return name + " (" + out.width + "x" + out.height + ")"
    }

    // ---------- Download ----------

    private fun startDownload(thumbSpec: ThumbSpec?) {
        val res = selected ?: return
        val url = urlInput.text?.toString()?.trim().orEmpty()
        busy = true
        updateButton()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        progress.isIndeterminate = false
        progress.setProgressCompat(0, false)
        progress.visibility = View.VISIBLE
        status.text = "Baixando… (mantenha o app aberto)"

        lifecycleScope.launch {
            try {
                var thumbNote = ""
                var verifyNote = ""
                val finalName = withContext(Dispatchers.IO) {
                    dlDir.deleteRecursively()
                    dlDir.mkdirs()

                    if (thumbSpec != null) {
                        val bmp = thumbOriginal
                        thumbNote = if (bmp == null) {
                            "\nThumb: indisponível"
                        } else {
                            try {
                                "\nThumb salva em Downloads/VR360/" + saveThumb(bmp, thumbSpec)
                            } catch (e: Exception) {
                                "\nThumb falhou: " + e.message
                            }
                        }
                    }

                    val req = YoutubeDLRequest(url)
                    req.addOption("--no-playlist")
                    // Formato exato escolhido (resolução original) + melhor áudio
                    req.addOption(
                        "-f",
                        "${res.formatId}+ba[ext=m4a]/${res.formatId}+ba/${res.formatId}"
                    )
                    req.addOption("--merge-output-format", "mp4")
                    req.addOption("--no-mtime")
                    req.addOption("-o", dlDir.absolutePath + "/%(id)s.%(ext)s")

                    YoutubeDL.getInstance().execute(req, "vr-download") { p, _, line ->
                        runOnUiThread {
                            if (line.contains("[Merger]") || line.contains("Merging")) {
                                status.text = "Mesclando vídeo e áudio…"
                            } else if (p >= 0f) {
                                progress.setProgressCompat(p.toInt().coerceIn(0, 100), true)
                                status.text = "Baixando… ${p.toInt()}%"
                            }
                        }
                    }

                    val file = dlDir.listFiles()
                        ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                        ?.maxByOrNull { it.length() }
                        ?: throw IllegalStateException("Arquivo final não encontrado")

                    val name = safeName(videoTitle) + " ${res.width}x${res.height}." + file.extension
                    runOnUiThread { status.text = "Verificando se o vídeo toca…" }
                    verifyNote = "\n" + verifyPlayable(file)
                    saveToDownloads(file, name)
                    file.delete()
                    name
                }
                progress.setProgressCompat(100, false)
                status.text = "Concluído!\nSalvo em Downloads/VR360/$finalName$thumbNote$verifyNote"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = "Erro no download:\n" + cleanError(e.message)
                progress.visibility = View.GONE
            } finally {
                busy = false
                updateButton()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    private fun saveToDownloads(file: File, displayName: String) {
        val mime = when (file.extension.lowercase()) {
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            else -> "video/mp4"
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/VR360")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Não foi possível criar o arquivo em Downloads")
        contentResolver.openOutputStream(uri)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
    }

    private fun safeName(s: String): String =
        s.replace(Regex("""[\\/:*?"<>|\r\n\t]"""), "_").trim().take(80).ifEmpty { "video" }

    private fun formatDuration(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
    }
}
