package com.vrdownloader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

class LibraryTab(private val a: AppCompatActivity, private val store: StoreTab) {

    private class EditPlan(
        val repo: String,
        val token: String,
        val id: String,
        val oldUrl: String,
        val nome: String,
        val tipo: String,
        val formato: String?,
        val newSize: Long?,
        val miniatura: String,
        val url: String,
        val thumbBytes: ByteArray?,
        val thumbPath: String?,
        val thumbSha: String?,
        val contentUri: Uri?,
        val contentAsset: String,
        val mime: String,
        val contentSize: Long,
        val releaseId: Long,
        val replaceAssetId: Long?,
        val deleteOldAssetId: Long?,
        val deleteOldThumbPath: String?,
        val summary: String
    )

    private class DeletePlan(
        val repo: String,
        val token: String,
        val id: String,
        val url: String,
        val nome: String,
        val assetName: String?,
        val thumbPath: String?,
        val summary: String
    )

    // lista
    private val listScroll: View = a.findViewById(R.id.libListScroll)
    private val refreshBtn: MaterialButton = a.findViewById(R.id.libRefresh)
    private val libStatus: TextView = a.findViewById(R.id.libStatus)
    private val libList: LinearLayout = a.findViewById(R.id.libList)

    // edição
    private val editScroll: View = a.findViewById(R.id.libEditScroll)
    private val backBtn: MaterialButton = a.findViewById(R.id.editBack)
    private val editInfo: TextView = a.findViewById(R.id.editInfo)
    private val editName: TextInputEditText = a.findViewById(R.id.editName)
    private val editThumbPreview: ImageView = a.findViewById(R.id.editThumbPreview)
    private val editThumbText: TextView = a.findViewById(R.id.editThumbText)
    private val editThumbPick: MaterialButton = a.findViewById(R.id.editThumbPick)
    private val editThumbGen: MaterialButton = a.findViewById(R.id.editThumbGen)
    private val editContentText: TextView = a.findViewById(R.id.editContentText)
    private val editContentPick: MaterialButton = a.findViewById(R.id.editContentPick)
    private val editFormatLabel: TextView = a.findViewById(R.id.editFormatLabel)
    private val editFormatGroup: ChipGroup = a.findViewById(R.id.editFormatGroup)
    private val editSave: MaterialButton = a.findViewById(R.id.editSave)
    private val editDelete: MaterialButton = a.findViewById(R.id.editDelete)
    private val progress: LinearProgressIndicator = a.findViewById(R.id.editProgress)
    private val editStatus: TextView = a.findViewById(R.id.editStatus)

    private var items: List<JSONObject> = emptyList()
    private var loaded = false
    private var cur: JSONObject? = null
    private var newThumbUri: Uri? = null
    private var newThumbName = ""
    private var newContentUri: Uri? = null
    private var newContentName = ""
    private var newContentSize = 0L
    private var newContentKind = ""
    private var formatTouched = false
    private var suppressFormat = false
    private var busy = false
    private val thumbCache = HashMap<String, Bitmap>()

    private val pickThumb = a.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onNewThumb(uri)
    }
    private val pickContent = a.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onNewContent(uri)
    }
    private val maker = ThumbMaker(a) { uri -> onNewThumb(uri) }
    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (!busy) closeEdit()
        }
    }

    init {
        a.onBackPressedDispatcher.addCallback(a, backCb)
        refreshBtn.setOnClickListener { refresh() }
        backBtn.setOnClickListener { if (!busy) closeEdit() }
        editThumbPick.setOnClickListener { pickThumb.launch(arrayOf("image/*")) }
        editThumbGen.setOnClickListener { maker.show() }
        editContentPick.setOnClickListener { pickContent.launch(arrayOf("video/mp4", "image/jpeg")) }
        editFormatGroup.setOnCheckedStateChangeListener { _, _ ->
            if (!suppressFormat) formatTouched = true
        }
        editSave.setOnClickListener { onSave() }
        editDelete.setOnClickListener { onDelete() }
    }

    fun onShown() {
        if (!loaded) refresh()
    }

    // ---------- lista ----------

    private fun refresh() {
        val (token, repo) = store.credentials()
        if (token.isEmpty() || !repo.contains("/")) {
            libStatus.text = "Preencha o token e o repositório na aba Enviar."
            return
        }
        libStatus.text = "Carregando…"
        thumbCache.clear()
        a.lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    (GitHub.getFile(repo, GitHub.CATALOG, GitHub.BRANCH, token)
                        ?: throw IllegalStateException("catalogo.json não encontrado")).text
                }
                val arr = GitHub.findArray(JSONTokener(text).nextValue())
                    ?: throw IllegalStateException("O catalogo.json não tem uma lista de itens")
                val list = ArrayList<JSONObject>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i)
                    if (o != null) list.add(o)
                }
                items = list
                loaded = true
                render()
                libStatus.text = list.size.toString() + " itens"
            } catch (e: Exception) {
                libStatus.text = "Erro: " + e.message
            }
        }
    }

    private fun render() {
        libList.removeAllViews()
        for (o in items) {
            val row = a.layoutInflater.inflate(R.layout.item_library, libList, false)
            val iv = row.findViewById<ImageView>(R.id.itemThumb)
            row.findViewById<TextView>(R.id.itemName).text = o.optString("nome")
            row.findViewById<TextView>(R.id.itemMeta).text = metaText(o)
            row.setOnClickListener { openEdit(o) }
            libList.addView(row)
            val mini = o.optString("miniatura")
            if (mini.isNotEmpty()) loadThumb(mini, iv)
        }
    }

    private fun metaText(o: JSONObject): String {
        val kind = if (o.optString("tipo") == "video") "Vídeo" else "Imagem"
        val sb = StringBuilder(kind)
        val f = o.optString("formato")
        if (f.isNotEmpty()) sb.append(" · ").append(f)
        sb.append(" · ").append(Util.fmtSize(o.optLong("tamanho")))
        return sb.toString()
    }

    private fun loadThumb(url: String, iv: ImageView) {
        val cached = thumbCache[url]
        if (cached != null) {
            iv.setImageBitmap(cached)
            return
        }
        a.lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val sep = if (url.contains('?')) "&" else "?"
                    val c = URL(url + sep + "cb=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    try {
                        c.inputStream.use { BitmapFactory.decodeStream(it) }
                    } finally {
                        c.disconnect()
                    }
                } catch (e: Exception) {
                    null
                }
            }
            if (bmp != null) {
                thumbCache[url] = bmp
                iv.setImageBitmap(bmp)
            }
        }
    }

    // ---------- edição ----------

    private fun openEdit(o: JSONObject) {
        cur = o
        newThumbUri = null; newThumbName = ""
        newContentUri = null; newContentName = ""; newContentSize = 0L; newContentKind = ""
        formatTouched = false
        editStatus.text = ""
        progress.visibility = View.GONE

        editInfo.text = "id: " + o.optString("id")
        editName.setText(o.optString("nome"))

        val mini = o.optString("miniatura")
        editThumbPreview.setImageDrawable(null)
        if (mini.isNotEmpty()) loadThumb(mini, editThumbPreview)
        editThumbText.text = "Atual: " + mini.substringAfterLast('/')

        val tipo = o.optString("tipo")
        editContentText.text = "Atual: " + o.optString("url").substringAfterLast('/') + "\n" +
            (if (tipo == "video") "Vídeo" else "Imagem") + " · " + Util.fmtSize(o.optLong("tamanho"))

        if (tipo == "video") {
            val f = o.optString("formato")
            editFormatLabel.visibility = View.VISIBLE
            editFormatGroup.visibility = View.VISIBLE
            editFormatLabel.text = if (f.isEmpty()) "Formato do vídeo (não definido no catálogo)"
            else "Formato do vídeo (atual: $f)"
            suppressFormat = true
            when (f) {
                Util.TOP_BOTTOM -> editFormatGroup.check(R.id.eChipTB)
                Util.LR -> editFormatGroup.check(R.id.eChipLR)
                else -> editFormatGroup.check(R.id.eChipMono)
            }
            suppressFormat = false
        } else {
            editFormatLabel.visibility = View.GONE
            editFormatGroup.visibility = View.GONE
        }

        listScroll.visibility = View.GONE
        editScroll.visibility = View.VISIBLE
        editScroll.scrollTo(0, 0)
        backCb.isEnabled = true
    }

    private fun closeEdit() {
        cur = null
        editScroll.visibility = View.GONE
        listScroll.visibility = View.VISIBLE
        backCb.isEnabled = false
    }

    private fun onNewThumb(uri: Uri) {
        if (cur == null) return
        val name = Util.queryName(a, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in listOf("jpg", "jpeg", "png", "webp")) {
            editStatus.text = "A thumb precisa ser .jpg ou .png"
            return
        }
        newThumbUri = uri
        newThumbName = name
        editThumbText.text = "Nova: $name (substitui a atual ao salvar)"
        val bmp = Util.decodeSampled(a, uri, 600)
        if (bmp != null) editThumbPreview.setImageBitmap(bmp)
        editStatus.text = ""
    }

    private fun onNewContent(uri: Uri) {
        val c = cur ?: return
        val name = Util.queryName(a, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        val kind = when (ext) {
            "mp4" -> "video"
            "jpg", "jpeg" -> "imagem"
            else -> ""
        }
        if (kind.isEmpty()) {
            editStatus.text = "Formato não suportado. Use .mp4 (vídeo) ou .jpg (imagem)."
            return
        }
        newContentUri = uri
        newContentName = name
        newContentKind = kind
        newContentSize = Util.querySize(a, uri)
        editContentText.text = "Novo: $name\n" + (if (kind == "video") "Vídeo" else "Imagem") +
            " · " + Util.fmtSize(newContentSize) + " (substitui o atual ao salvar)"
        if (kind == "video") {
            editFormatLabel.visibility = View.VISIBLE
            editFormatGroup.visibility = View.VISIBLE
            if (c.optString("tipo") != "video") {
                editFormatLabel.text = "Formato do vídeo (sugerido pela proporção)"
                when (Util.suggestFormat(a, uri)) {
                    Util.TOP_BOTTOM -> editFormatGroup.check(R.id.eChipTB)
                    Util.LR -> editFormatGroup.check(R.id.eChipLR)
                    else -> editFormatGroup.check(R.id.eChipMono)
                }
                formatTouched = true
            }
        } else {
            editFormatLabel.visibility = View.GONE
            editFormatGroup.visibility = View.GONE
        }
        editStatus.text = ""
    }

    private fun selectedFormat(): String = when (editFormatGroup.checkedChipId) {
        R.id.eChipTB -> Util.TOP_BOTTOM
        R.id.eChipLR -> Util.LR
        else -> Util.MONO
    }

    private fun setBusy(b: Boolean) {
        busy = b
        editSave.isEnabled = !b
        editDelete.isEnabled = !b
        backBtn.isEnabled = !b
        editThumbPick.isEnabled = !b
        editThumbGen.isEnabled = !b
        editContentPick.isEnabled = !b
        if (b) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun ui(block: () -> Unit) {
        a.runOnUiThread { block() }
    }

    private fun assetNameFromUrl(url: String, repo: String): String? {
        val prefix = "https://github.com/$repo/releases/download/${GitHub.TAG}/"
        return if (url.startsWith(prefix)) URLDecoder.decode(url.removePrefix(prefix), "UTF-8") else null
    }

    private fun thumbPathFromUrl(url: String, repo: String): String? {
        val prefix = GitHub.RAW_BASE + repo + "/" + GitHub.BRANCH + "/"
        val path = if (url.startsWith(prefix)) url.removePrefix(prefix) else return null
        return if (path.startsWith("loja/")) path else null
    }

    // ---------- salvar alterações ----------

    private fun onSave() {
        val c = cur ?: return
        if (busy) return
        val (token, repo) = store.credentials()
        if (token.isEmpty() || !repo.contains("/")) {
            editStatus.text = "Preencha o token e o repositório na aba Enviar."
            return
        }
        val nome = editName.text?.toString()?.trim().orEmpty()
        if (nome.isEmpty()) {
            editStatus.text = "O nome não pode ficar vazio."
            return
        }
        val oldNome = c.optString("nome")
        val oldTipo = c.optString("tipo")
        val oldFormato: String? = if (c.has("formato") && !c.isNull("formato")) c.optString("formato") else null
        val newKind = if (newContentUri != null) newContentKind else oldTipo
        val newFormato: String? = when {
            newKind != "video" -> null
            formatTouched -> selectedFormat()
            else -> oldFormato
        }
        val thumbUri = newThumbUri
        val contentUri = newContentUri
        val changed = nome != oldNome || newKind != oldTipo || newFormato != oldFormato ||
            thumbUri != null || contentUri != null
        if (!changed) {
            editStatus.text = "Nada foi alterado."
            return
        }

        setBusy(true)
        progress.visibility = View.GONE
        editStatus.text = "Verificando…"
        a.lifecycleScope.launch {
            try {
                val plan = withContext(Dispatchers.IO) {
                    prepareEdit(repo, token, c, nome, newKind, newFormato, oldFormato, thumbUri, contentUri)
                }
                setBusy(false)
                MaterialAlertDialogBuilder(a)
                    .setTitle("Salvar alterações?")
                    .setMessage(plan.summary)
                    .setNegativeButton("Cancelar") { _, _ -> editStatus.text = "" }
                    .setPositiveButton("Salvar") { _, _ -> executeEdit(plan) }
                    .show()
            } catch (e: Exception) {
                setBusy(false)
                editStatus.text = "Erro: " + e.message
            }
        }
    }

    private fun prepareEdit(
        repo: String, token: String, c: JSONObject, nome: String, tipo: String,
        formato: String?, oldFormato: String?, thumbUri: Uri?, contentUri: Uri?
    ): EditPlan {
        val id = c.optString("id")
        val oldUrl = c.optString("url")
        val oldMini = c.optString("miniatura")

        val cat = GitHub.getFile(repo, GitHub.CATALOG, GitHub.BRANCH, token)
            ?: throw IllegalStateException("catalogo.json não encontrado")
        val arr = GitHub.findArray(JSONTokener(cat.text).nextValue())
            ?: throw IllegalStateException("O catalogo.json não tem uma lista de itens")
        val others = ArrayList<JSONObject>()
        var found = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!found && o.optString("id") == id && o.optString("url") == oldUrl) {
                found = true
            } else {
                others.add(o)
            }
        }
        if (!found) throw IllegalStateException("Esse item não está mais no catálogo. Atualize a lista.")

        val lines = ArrayList<String>()
        if (nome != c.optString("nome")) lines.add("• Nome: \"" + c.optString("nome") + "\" → \"" + nome + "\"")
        if (tipo != c.optString("tipo")) lines.add("• Tipo: " + c.optString("tipo") + " → " + tipo)
        if (formato != oldFormato) lines.add("• Formato: " + (oldFormato ?: "(nenhum)") + " → " + (formato ?: "(nenhum)"))

        var miniatura = oldMini
        var thumbBytes: ByteArray? = null
        var thumbPath: String? = null
        var thumbSha: String? = null
        var deleteOldThumb: String? = null
        if (thumbUri != null) {
            val asset = Util.sanitize(Util.baseName(newThumbName)) + ".jpg"
            thumbPath = GitHub.THUMBS + asset
            miniatura = GitHub.RAW_BASE + repo + "/" + GitHub.BRANCH + "/" + thumbPath
            if (miniatura != oldMini && others.any { it.optString("miniatura") == miniatura }) {
                throw IllegalStateException("A thumb $asset já é usada por outro item. Renomeie o arquivo.")
            }
            thumbSha = GitHub.getFile(repo, thumbPath, GitHub.BRANCH, token)?.sha
            thumbBytes = Util.loadThumbJpeg(a, thumbUri, newThumbName)
            val oldPath = thumbPathFromUrl(oldMini, repo)
            if (oldPath != null && miniatura != oldMini && others.none { it.optString("miniatura") == oldMini }) {
                deleteOldThumb = oldPath
            }
            lines.add("• Thumb: troca por $asset" + (if (deleteOldThumb != null) " (apaga a antiga)" else ""))
        }

        var url = oldUrl
        var releaseId = 0L
        var replaceAssetId: Long? = null
        var deleteOldAssetId: Long? = null
        var contentAsset = ""
        var mime = ""
        var newSize: Long? = null
        if (contentUri != null) {
            if (newContentSize <= 0) throw IllegalStateException("Não consegui ler o tamanho do arquivo")
            val release = GitHub.getRelease(repo, GitHub.TAG, token)
            releaseId = release.id
            contentAsset = Util.sanitize(Util.baseName(newContentName)) + "." +
                (if (newContentKind == "video") "mp4" else "jpg")
            mime = if (newContentKind == "video") "video/mp4" else "image/jpeg"
            url = "https://github.com/$repo/releases/download/${GitHub.TAG}/$contentAsset"
            if (url != oldUrl && others.any { it.optString("url") == url }) {
                throw IllegalStateException("O arquivo $contentAsset já é usado por outro item. Renomeie o arquivo.")
            }
            replaceAssetId = release.assets[contentAsset]
            val oldName = assetNameFromUrl(oldUrl, repo)
            if (oldName != null && url != oldUrl && others.none { it.optString("url") == oldUrl }) {
                deleteOldAssetId = release.assets[oldName]
            }
            newSize = newContentSize
            lines.add(
                "• Arquivo: troca por $contentAsset (" + Util.fmtSize(newContentSize) + ")" +
                    (if (deleteOldAssetId != null) " (apaga o antigo)" else "")
            )
        }

        if (thumbUri == null && contentUri == null) lines.add("\nSó o catalogo.json será atualizado.")
        return EditPlan(
            repo, token, id, oldUrl, nome, tipo, formato, newSize, miniatura, url,
            thumbBytes, thumbPath, thumbSha, contentUri, contentAsset, mime, newContentSize,
            releaseId, replaceAssetId, deleteOldAssetId, deleteOldThumb, lines.joinToString("\n")
        )
    }

    private fun executeEdit(p: EditPlan) {
        setBusy(true)
        progress.isIndeterminate = false
        progress.setProgressCompat(0, false)
        progress.visibility = View.VISIBLE
        a.lifecycleScope.launch {
            val warnings = ArrayList<String>()
            try {
                withContext(Dispatchers.IO) {
                    if (p.thumbBytes != null && p.thumbPath != null) {
                        ui { editStatus.text = "Enviando thumb…" }
                        GitHub.putFile(
                            p.repo, p.thumbPath, GitHub.BRANCH, p.token, p.thumbBytes,
                            "Atualiza thumb " + p.thumbPath.substringAfterLast('/'), p.thumbSha
                        )
                    }

                    if (p.contentUri != null) {
                        if (p.replaceAssetId != null) {
                            ui { editStatus.text = "Substituindo arquivo na release…" }
                            GitHub.deleteAsset(p.repo, p.replaceAssetId, p.token)
                        }
                        var lastPct = -1
                        ui { editStatus.text = "Enviando arquivo… 0%" }
                        val input = a.contentResolver.openInputStream(p.contentUri)
                            ?: throw IllegalStateException("Não consegui abrir o arquivo")
                        input.use {
                            GitHub.uploadAsset(
                                p.repo, p.releaseId, p.contentAsset, p.mime, p.contentSize, p.token, it
                            ) { sent ->
                                val pct = (sent * 100 / p.contentSize).toInt()
                                if (pct != lastPct) {
                                    lastPct = pct
                                    ui {
                                        progress.setProgressCompat(pct, true)
                                        editStatus.text = "Enviando arquivo… $pct%"
                                    }
                                }
                            }
                        }
                    }

                    ui { editStatus.text = "Atualizando catalogo.json…" }
                    val cat = GitHub.getFile(p.repo, GitHub.CATALOG, GitHub.BRANCH, p.token)
                        ?: throw IllegalStateException("catalogo.json sumiu do repositório")
                    val sp = GitHub.findItemSpan(cat.text, p.id, p.oldUrl)
                        ?: throw IllegalStateException("Item não encontrado no catálogo (mudou?)")
                    val oldObj = JSONObject(cat.text.substring(sp.start, sp.end))
                    val size = p.newSize ?: oldObj.optLong("tamanho")
                    val map = GitHub.rebuild(oldObj, p.nome, p.tipo, p.formato, size, p.miniatura, p.url)
                    val newObj = GitHub.objectJson(map, GitHub.lineIndent(cat.text, sp.start))
                    val newText = GitHub.replaceItem(cat.text, sp, newObj)
                    GitHub.verifyEdited(cat.text, newText, oldObj.toString())
                    GitHub.putFile(
                        p.repo, GitHub.CATALOG, GitHub.BRANCH, p.token,
                        newText.toByteArray(Charsets.UTF_8), "Edita " + p.nome, cat.sha
                    )

                    // limpeza dos arquivos antigos (só depois do catálogo estar certo)
                    if (p.deleteOldAssetId != null) {
                        try {
                            GitHub.deleteAsset(p.repo, p.deleteOldAssetId, p.token)
                        } catch (e: Exception) {
                            warnings.add("Não consegui apagar o arquivo antigo: " + e.message)
                        }
                    }
                    if (p.deleteOldThumbPath != null) {
                        try {
                            val f = GitHub.getFile(p.repo, p.deleteOldThumbPath, GitHub.BRANCH, p.token)
                            if (f != null) {
                                GitHub.deleteFile(
                                    p.repo, p.deleteOldThumbPath, GitHub.BRANCH, p.token, f.sha,
                                    "Remove thumb antiga"
                                )
                            }
                        } catch (e: Exception) {
                            warnings.add("Não consegui apagar a thumb antiga: " + e.message)
                        }
                    }
                }
                progress.setProgressCompat(100, false)
                editStatus.text = "Pronto! Item atualizado." +
                    (if (warnings.isNotEmpty()) "\n" + warnings.joinToString("\n") else "")
                closeEdit()
                refresh()
            } catch (e: Exception) {
                progress.visibility = View.GONE
                editStatus.text = "Erro: " + e.message +
                    "\n(Se algo já subiu, é só salvar de novo: o app substitui.)"
            } finally {
                setBusy(false)
            }
        }
    }

    // ---------- excluir ----------

    private fun onDelete() {
        val c = cur ?: return
        if (busy) return
        val (token, repo) = store.credentials()
        if (token.isEmpty() || !repo.contains("/")) {
            editStatus.text = "Preencha o token e o repositório na aba Enviar."
            return
        }
        setBusy(true)
        editStatus.text = "Verificando…"
        a.lifecycleScope.launch {
            try {
                val plan = withContext(Dispatchers.IO) { prepareDelete(repo, token, c) }
                setBusy(false)
                MaterialAlertDialogBuilder(a)
                    .setTitle("Excluir \"" + plan.nome + "\"?")
                    .setMessage(plan.summary + "\n\nIsso não pode ser desfeito.")
                    .setNegativeButton("Cancelar") { _, _ -> editStatus.text = "" }
                    .setPositiveButton("Excluir") { _, _ -> executeDelete(plan) }
                    .show()
            } catch (e: Exception) {
                setBusy(false)
                editStatus.text = "Erro: " + e.message
            }
        }
    }

    private fun prepareDelete(repo: String, token: String, c: JSONObject): DeletePlan {
        val id = c.optString("id")
        val url = c.optString("url")
        val mini = c.optString("miniatura")
        val cat = GitHub.getFile(repo, GitHub.CATALOG, GitHub.BRANCH, token)
            ?: throw IllegalStateException("catalogo.json não encontrado")
        val arr = GitHub.findArray(JSONTokener(cat.text).nextValue())
            ?: throw IllegalStateException("O catalogo.json não tem uma lista de itens")
        val others = ArrayList<JSONObject>()
        var found = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!found && o.optString("id") == id && o.optString("url") == url) found = true else others.add(o)
        }
        if (!found) throw IllegalStateException("Esse item não está mais no catálogo. Atualize a lista.")

        val assetName = if (others.none { it.optString("url") == url }) assetNameFromUrl(url, repo) else null
        val thumbPath = if (others.none { it.optString("miniatura") == mini }) thumbPathFromUrl(mini, repo) else null

        val sb = StringBuilder("Será apagado:\n• O item do catalogo.json")
        if (assetName != null) sb.append("\n• O arquivo ").append(assetName).append(" da release")
        else sb.append("\n• (o arquivo da release NÃO será apagado: link fora do padrão ou usado por outro item)")
        if (thumbPath != null) sb.append("\n• A thumb ").append(thumbPath.substringAfterLast('/'))
        else sb.append("\n• (a thumb NÃO será apagada: link fora do padrão ou usada por outro item)")
        return DeletePlan(repo, token, id, url, c.optString("nome"), assetName, thumbPath, sb.toString())
    }

    private fun executeDelete(p: DeletePlan) {
        setBusy(true)
        progress.visibility = View.GONE
        a.lifecycleScope.launch {
            val warnings = ArrayList<String>()
            try {
                withContext(Dispatchers.IO) {
                    ui { editStatus.text = "Removendo do catálogo…" }
                    val cat = GitHub.getFile(p.repo, GitHub.CATALOG, GitHub.BRANCH, p.token)
                        ?: throw IllegalStateException("catalogo.json sumiu do repositório")
                    val sp = GitHub.findItemSpan(cat.text, p.id, p.url)
                        ?: throw IllegalStateException("Item não encontrado no catálogo (mudou?)")
                    val oldObjText = JSONObject(cat.text.substring(sp.start, sp.end)).toString()
                    val newText = GitHub.removeItem(cat.text, sp)
                    GitHub.verifyRemoved(cat.text, newText, oldObjText)
                    GitHub.putFile(
                        p.repo, GitHub.CATALOG, GitHub.BRANCH, p.token,
                        newText.toByteArray(Charsets.UTF_8), "Remove " + p.nome, cat.sha
                    )

                    if (p.assetName != null) {
                        ui { editStatus.text = "Apagando arquivo da release…" }
                        try {
                            val release = GitHub.getRelease(p.repo, GitHub.TAG, p.token)
                            val aid = release.assets[p.assetName]
                            if (aid != null) GitHub.deleteAsset(p.repo, aid, p.token)
                        } catch (e: Exception) {
                            warnings.add("Não consegui apagar o arquivo da release: " + e.message)
                        }
                    }
                    if (p.thumbPath != null) {
                        ui { editStatus.text = "Apagando thumb…" }
                        try {
                            val f = GitHub.getFile(p.repo, p.thumbPath, GitHub.BRANCH, p.token)
                            if (f != null) {
                                GitHub.deleteFile(
                                    p.repo, p.thumbPath, GitHub.BRANCH, p.token, f.sha,
                                    "Remove thumb de " + p.nome
                                )
                            }
                        } catch (e: Exception) {
                            warnings.add("Não consegui apagar a thumb: " + e.message)
                        }
                    }
                }
                editStatus.text = "Item excluído." +
                    (if (warnings.isNotEmpty()) "\n" + warnings.joinToString("\n") else "")
                closeEdit()
                refresh()
            } catch (e: Exception) {
                editStatus.text = "Erro: " + e.message
            } finally {
                setBusy(false)
            }
        }
    }
}
