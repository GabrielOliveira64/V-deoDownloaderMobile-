package com.vrdownloader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.text.Normalizer
import java.util.Locale

object Util {
    const val MONO = "mono"
    const val TOP_BOTTOM = "top-bottom"
    const val LR = "LR"

    fun queryName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }

    fun querySize(ctx: Context, uri: Uri): Long {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.SIZE)
            if (i >= 0 && c.moveToFirst() && !c.isNull(i)) return c.getLong(i)
        }
        return ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
    }

    fun baseName(name: String): String =
        if (name.contains('.')) name.substringBeforeLast('.') else name

    fun sanitize(s: String): String {
        val noAccents = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        val r = noAccents.replace(Regex("[^A-Za-z0-9._-]"), "_").replace(Regex("_+"), "_").trim('_')
        return r.ifEmpty { "arquivo" }
    }

    fun fmtSize(bytes: Long): String =
        if (bytes >= 1048576) String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        else String.format(Locale.US, "%.0f KB", bytes / 1024.0)

    fun decodeSampled(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > maxSide || o.outHeight / s > maxSide) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Exception) {
            null
        }
    }

    // .jpg vai como está; .png/.webp são convertidos para .jpg
    fun loadThumbJpeg(ctx: Context, uri: Uri, fileName: String): ByteArray {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "jpg" || ext == "jpeg") {
            return ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Não consegui abrir a thumb")
        }
        val bmp = decodeSampled(ctx, uri, 2048) ?: throw IllegalStateException("Não consegui ler a thumb")
        val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(flat)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(bmp, 0f, 0f, null)
        val out = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, 92, out)
        return out.toByteArray()
    }

    // Sugere o formato do vídeo pela proporção (o usuário confirma/muda)
    fun suggestFormat(ctx: Context, uri: Uri): String {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            if (w <= 0 || h <= 0) {
                MONO
            } else {
                val ratio = w.toFloat() / h
                when {
                    ratio >= 3.5f -> LR
                    ratio >= 1.95f -> MONO
                    else -> TOP_BOTTOM
                }
            }
        } catch (e: Exception) {
            MONO
        } finally {
            r.release()
        }
    }
}
