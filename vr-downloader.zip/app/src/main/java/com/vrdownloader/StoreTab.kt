package com.vrdownloader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import java.io.ByteArrayOutputStream
import java.text.Normalizer
import java.util.Locale

class StoreTab(private val a: AppCompatActivity) {

    private companion object {
        const val TAG = "loja"
        const val BRANCH = "main"
        const val CATALOG = "loja/catalogo.json"
        const val THUMBS = "loja/thumbs/"
    }

    private class Plan(
        val repo: String,
        val token: String,
        val releaseId: Long,
        val thumbBytes: ByteArray,
        val thumbAsset: String,
        val thumbSha: String?,
        val contentUri: Uri,
        val contentAsset: String,
        val replaceAssetId: Long?,
        val mime: String,
        val size: Long,
        val nome: String,
        val entry: String
    )

    private val prefs = a.getSharedPreferences("store", Context.MODE_PRIVATE)
    private val tokenInput: TextInputEditText = a.findViewById(R.id.tokenInput)
    private val repoInput: TextInputEditText = a.findViewById(R.id.repoInput)
    private val thumbBtn: MaterialButton = a.findViewById(R.id.thumbBtn)
    private val thumbPreview: ImageView = a.findViewById(R.id.thumbPreview)
    private val thumbText: TextView = a.findViewById(R.id.thumbText)
    private val contentBtn: MaterialButton = a.findViewById(R.id.contentBtn)
    private val contentText: TextView = a.findViewById(R.id.contentText)
    private val nameInput: TextInputEditText = a.findViewById(R.id.nameInput)
    private val sendBtn: MaterialButton = a.findViewById(R.id.sendBtn)
    private val progress: LinearProgressIndicator = a.findViewById(R.id.storeProgress)
    private val status: TextView = a.findViewById(R.id.storeStatus)

    private var thumbUri: Uri? = null
    private var thumbName = ""
    private var contentUri: Uri? = null
    private var contentName = ""
    private var contentSize = 0L
    private var contentKind = ""
    private var lastAuto = ""
    private var busy = false

    private val pickThumb = a.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onThumb(uri)
    }
    private val pickContent = a.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onContent(uri)
    }

    init {
        tokenInput.setText(prefs.getString("token", ""))
        repoInput.setText(prefs.getString("repo", "GabrielOliveira64/VrLauncher"))
        thumbBtn.setOnClickListener { pickThumb.launch(arrayOf("image/*")) }
        contentBtn.setOnClickListener { pickContent.launch(arrayOf("video/mp4", "image/jpeg")) }
        sendBtn.setOnClickListener { onSend() }
    }

    // ---------- seleção de arquivos ----------

    private fun onThumb(uri: Uri) {
        val name = queryName(uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in listOf("jpg", "jpeg", "png", "webp")) {
            status.text = "A thumb precisa ser .jpg ou .png"
            return
        }
        thumbUri = uri
        thumbName = name
        thumbText.text = name
        val bmp = decodeSampled(uri, 600)
        if (bmp != null) {
            thumbPreview.setImageBitmap(bmp)
            thumbPreview.visibility = View.VISIBLE
        }
        val auto = baseName(name).replace(Regex("""[_\- ]?thumbs?$""", RegexOption.IGNORE_CASE), "")
        val cur = nameInput.text?.toString().orEmpty()
        if (cur.isEmpty() || cur == lastAuto) nameInput.setText(auto)
        lastAuto = auto
        status.text = ""
    }

    private fun onContent(uri: Uri) {
        val name = queryName(uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        val kind = when (ext) {
            "mp4" -> "video"
            "jpg", "jpeg" -> "imagem"
            else -> ""
        }
        if (kind.isEmpty()) {
            status.text = "Formato não suportado. Use .mp4 (vídeo) ou .jpg (imagem)."
            return
        }
        contentUri = uri
        contentName = name
        contentKind = kind
        contentSize = querySize(uri)
        contentText.text = name + "\n" + (if (kind == "video") "Vídeo" else "Imagem") +
            " · " + fmtSize(contentSize)
        status.text = ""
    }

    // ---------- envio ----------

    private fun setBusy(b: Boolean) {
        busy = b
        sendBtn.isEnabled = !b
        thumbBtn.isEnabled = !b
        contentBtn.isEnabled = !b
        if (b) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun onSend() {
        if (busy) return
        val token = tokenInput.text?.toString()?.trim().orEmpty()
        val repo = repoInput.text?.toString()?.trim().orEmpty()
        if (token.isEmpty()) { status.text = "Cole o token do GitHub."; return }
        if (!repo.contains("/")) { status.text = "Repositório no formato dono/nome."; return }
        if (thumbUri == null) { status.text = "Selecione a thumb."; return }
        if (contentUri == null) { status.text = "Selecione o vídeo/imagem VR."; return }
        val nome = nameInput.text?.toString()?.trim().orEmpty()
        if (nome.isEmpty()) { status.text = "Digite o nome que aparece na loja."; return }

        prefs.edit().putString("token", token).putString("repo", repo).apply()
        setBusy(true)
        progress.visibility = View.GONE
        status.text = "Verificando repositório…"

        a.lifecycleScope.launch {
            try {
                val plan = withContext(Dispatchers.IO) { prepare(repo, token, nome) }
                setBusy(false)
                confirm(plan)
            } catch (e: Exception) {
                setBusy(false)
                status.text = "Erro: " + e.message
            }
        }
    }

    private fun prepare(repo: String, token: String, nome: String): Plan {
        val tUri = thumbUri!!
        val cUri = contentUri!!
        val thumbAsset = sanitize(baseName(thumbName)) + ".jpg"
        val contentBase = sanitize(baseName(contentName))
        val contentAsset = contentBase + "." + (if (contentKind == "video") "mp4" else "jpg")
        val mime = if (contentKind == "video") "video/mp4" else "image/jpeg"

        val release = GitHub.getRelease(repo, TAG, token)
        val cat = GitHub.getFile(repo, CATALOG, BRANCH, token)
            ?: throw IllegalStateException("Não achei $CATALOG no repositório")
        val list = GitHub.findArray(JSONTokener(cat.text).nextValue())
            ?: throw IllegalStateException("O catalogo.json não tem uma lista de itens")

        val url = "https://github.com/$repo/releases/download/$TAG/$contentAsset"
        val miniatura = "https://raw.githubusercontent.com/$repo/$BRANCH/$THUMBS$thumbAsset"

        val ids = HashSet<String>()
        for (i in 0 until list.length()) {
            val o = list.optJSONObject(i) ?: continue
            ids.add(o.optString("id"))
            if (o.optString("url") == url) {
                throw IllegalStateException("Já existe no catálogo um item com o arquivo $contentAsset. Renomeie o arquivo.")
            }
        }
        var id = contentBase
        var n = 2
        while (id in ids) { id = contentBase + "_" + n; n++ }

        val thumbSha = GitHub.getFile(repo, THUMBS + thumbAsset, BRANCH, token)?.sha
        val thumbBytes = loadThumbJpeg(tUri)
        val size = if (contentSize > 0) contentSize else throw IllegalStateException("Não consegui ler o tamanho do arquivo")

        val entry = GitHub.entryJson(id, nome, contentKind, size, miniatura, url)
        return Plan(
            repo, token, release.id, thumbBytes, thumbAsset, thumbSha, cUri, contentAsset,
            release.assets[contentAsset], mime, size, nome, entry
        )
    }

    private fun confirm(p: Plan) {
        val sb = StringBuilder()
        sb.append("Thumb: ").append(THUMBS).append(p.thumbAsset)
        if (p.thumbSha != null) sb.append("  (já existe, será substituída)")
        sb.append("\n\nArquivo: ").append(p.contentAsset).append(" (").append(fmtSize(p.size)).append(")")
        if (p.replaceAssetId != null) sb.append("  (já existe na release, será substituído)")
        sb.append("\n\nNovo item do catálogo:\n").append(p.entry.trimIndent())
        MaterialAlertDialogBuilder(a)
            .setTitle("Enviar para a loja?")
            .setMessage(sb.toString())
            .setNegativeButton("Cancelar") { _, _ -> status.text = "" }
            .setPositiveButton("Enviar") { _, _ -> upload(p) }
            .show()
    }

    private fun upload(p: Plan) {
        setBusy(true)
        progress.isIndeterminate = false
        progress.setProgressCompat(0, false)
        progress.visibility = View.VISIBLE
        a.lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ui { status.text = "Enviando thumb…" }
                    GitHub.putFile(p.repo, THUMBS + p.thumbAsset, BRANCH, p.token, p.thumbBytes,
                        "Adiciona thumb " + p.thumbAsset, p.thumbSha)

                    if (p.replaceAssetId != null) {
                        ui { status.text = "Removendo arquivo antigo da release…" }
                        GitHub.deleteAsset(p.repo, p.replaceAssetId, p.token)
                    }

                    var lastPct = -1
                    ui { status.text = "Enviando arquivo… 0%" }
                    val input = a.contentResolver.openInputStream(p.contentUri)
                        ?: throw IllegalStateException("Não consegui abrir o arquivo")
                    input.use {
                        GitHub.uploadAsset(p.repo, p.releaseId, p.contentAsset, p.mime, p.size, p.token, it) { sent ->
                            val pct = (sent * 100 / p.size).toInt()
                            if (pct != lastPct) {
                                lastPct = pct
                                ui {
                                    progress.setProgressCompat(pct, true)
                                    status.text = "Enviando arquivo… $pct%"
                                }
                            }
                        }
                    }

                    ui { status.text = "Atualizando catalogo.json…" }
                    val cat = GitHub.getFile(p.repo, CATALOG, BRANCH, p.token)
                        ?: throw IllegalStateException("catalogo.json sumiu do repositório")
                    val newText = GitHub.appendEntry(cat.text, p.entry)
                    GitHub.verifyAppended(cat.text, newText)
                    GitHub.putFile(p.repo, CATALOG, BRANCH, p.token, newText.toByteArray(Charsets.UTF_8),
                        "Adiciona " + p.nome + " à loja", cat.sha)
                }
                progress.setProgressCompat(100, false)
                status.text = "Pronto! \"" + p.nome + "\" foi adicionado à loja."
                resetSelection()
            } catch (e: Exception) {
                progress.visibility = View.GONE
                status.text = "Erro: " + e.message +
                    "\n(Se a thumb ou o arquivo já subiram, é só enviar de novo: o app substitui.)"
            } finally {
                setBusy(false)
            }
        }
    }

    private fun resetSelection() {
        thumbUri = null; thumbName = ""
        contentUri = null; contentName = ""; contentSize = 0L; contentKind = ""
        thumbPreview.visibility = View.GONE
        thumbText.text = "Nenhuma thumb selecionada"
        contentText.text = "Nenhum arquivo selecionado (.mp4 ou .jpg)"
        nameInput.setText("")
        lastAuto = ""
    }

    // ---------- utilitários ----------

    private fun ui(block: () -> Unit) {
        a.runOnUiThread { block() }
    }

    private fun queryName(uri: Uri): String {
        a.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }

    private fun querySize(uri: Uri): Long {
        a.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.SIZE)
            if (i >= 0 && c.moveToFirst() && !c.isNull(i)) return c.getLong(i)
        }
        return a.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
    }

    private fun baseName(name: String): String =
        if (name.contains('.')) name.substringBeforeLast('.') else name

    // Remove acentos e troca caracteres especiais por "_" (igual ao que o GitHub aceita no link)
    private fun sanitize(s: String): String {
        val noAccents = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        val r = noAccents.replace(Regex("[^A-Za-z0-9._-]"), "_").replace(Regex("_+"), "_").trim('_')
        return r.ifEmpty { "arquivo" }
    }

    private fun fmtSize(bytes: Long): String =
        if (bytes >= 1048576) String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        else String.format(Locale.US, "%.0f KB", bytes / 1024.0)

    private fun decodeSampled(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > maxSide || o.outHeight / s > maxSide) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Exception) {
            null
        }
    }

    // .jpg vai como está; .png/.webp são convertidos para .jpg
    private fun loadThumbJpeg(uri: Uri): ByteArray {
        val ext = thumbName.substringAfterLast('.', "").lowercase()
        if (ext == "jpg" || ext == "jpeg") {
            return a.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Não consegui abrir a thumb")
        }
        val bmp = decodeSampled(uri, 2048) ?: throw IllegalStateException("Não consegui ler a thumb")
        val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(flat)
        canvas.drawColor(android.graphics.Color.WHITE)
        canvas.drawBitmap(bmp, 0f, 0f, null)
        val out = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, 92, out)
        return out.toByteArray()
    }
}
