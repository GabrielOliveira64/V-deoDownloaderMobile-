package com.vrdownloader

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object GitHub {

    const val TAG = "loja"
    const val BRANCH = "main"
    const val CATALOG = "loja/catalogo.json"
    const val THUMBS = "loja/thumbs/"
    const val RAW_BASE = "https://raw.githubusercontent.com/"

    class ApiException(message: String) : Exception(message)
    class Resp(val code: Int, val body: String)
    class Release(val id: Long, val assets: Map<String, Long>)
    class FileInfo(val sha: String, private val b64: String) {
        val text: String
            get() = String(Base64.decode(b64, Base64.DEFAULT), Charsets.UTF_8)
    }

    fun request(method: String, url: String, token: String, body: String? = null): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 30000
            c.readTimeout = 60000
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("User-Agent", "VR360-Downloader")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Resp(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun explain(r: Resp, what: String): String {
        val msg = try {
            JSONObject(r.body).optString("message")
        } catch (e: Exception) {
            ""
        }
        val hint = when (r.code) {
            401 -> "Token inválido ou expirado."
            403 -> "Sem permissão (o token precisa de Contents: Read and write neste repositório)."
            404 -> "Não encontrado (confira o repositório e se o token tem acesso a ele)."
            409 -> "Conflito: o arquivo mudou no GitHub enquanto enviava. Tente de novo."
            else -> ""
        }
        return "$what: HTTP ${r.code} $msg $hint".trim()
    }

    fun getRelease(repo: String, tag: String, token: String): Release {
        val r = request("GET", "https://api.github.com/repos/$repo/releases/tags/$tag", token)
        if (r.code != 200) throw ApiException(explain(r, "Release '$tag'"))
        val j = JSONObject(r.body)
        val arr = j.optJSONArray("assets") ?: JSONArray()
        val map = HashMap<String, Long>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            map[o.getString("name")] = o.getLong("id")
        }
        return Release(j.getLong("id"), map)
    }

    fun getFile(repo: String, path: String, branch: String, token: String): FileInfo? {
        val r = request("GET", "https://api.github.com/repos/$repo/contents/$path?ref=$branch", token)
        if (r.code == 404) return null
        if (r.code != 200) throw ApiException(explain(r, path))
        val j = JSONObject(r.body)
        val c = j.optString("content", "")
        if (c.isEmpty() && j.optLong("size", 0L) > 0L) {
            throw ApiException("$path é grande demais para a API do GitHub")
        }
        return FileInfo(j.getString("sha"), c)
    }

    fun putFile(
        repo: String, path: String, branch: String, token: String,
        bytes: ByteArray, message: String, sha: String?
    ) {
        val body = JSONObject()
        body.put("message", message)
        body.put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
        body.put("branch", branch)
        if (sha != null) body.put("sha", sha)
        val r = request("PUT", "https://api.github.com/repos/$repo/contents/$path", token, body.toString())
        if (r.code !in 200..201) throw ApiException(explain(r, "Gravar $path"))
    }

    fun deleteAsset(repo: String, assetId: Long, token: String) {
        val r = request("DELETE", "https://api.github.com/repos/$repo/releases/assets/$assetId", token)
        if (r.code != 204) throw ApiException(explain(r, "Apagar arquivo antigo da release"))
    }

    fun deleteFile(repo: String, path: String, branch: String, token: String, sha: String, message: String) {
        val body = JSONObject()
        body.put("message", message)
        body.put("sha", sha)
        body.put("branch", branch)
        val r = request("DELETE", "https://api.github.com/repos/$repo/contents/$path", token, body.toString())
        if (r.code != 200) throw ApiException(explain(r, "Apagar $path"))
    }

    fun uploadAsset(
        repo: String, releaseId: Long, name: String, mime: String, size: Long, token: String,
        input: InputStream, onProgress: (Long) -> Unit
    ) {
        val url = "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=" +
            URLEncoder.encode(name, "UTF-8")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 30000
            c.readTimeout = 600000
            c.setFixedLengthStreamingMode(size)
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("User-Agent", "VR360-Downloader")
            c.setRequestProperty("Content-Type", mime)
            c.outputStream.use { out ->
                val buf = ByteArray(64 * 1024)
                var sent = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    sent += n
                    onProgress(sent)
                }
            }
            val code = c.responseCode
            if (code != 201) {
                val text = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                throw ApiException(explain(Resp(code, text), "Enviar $name"))
            }
        } finally {
            c.disconnect()
        }
    }

    // ---------- catalogo.json ----------

    fun findArray(v: Any?): JSONArray? {
        if (v is JSONArray) return v
        if (v is JSONObject) {
            val keys = v.keys()
            while (keys.hasNext()) {
                val x = v.opt(keys.next())
                if (x is JSONArray) return x
            }
        }
        return null
    }

    private fun q(s: String): String {
        val sb = StringBuilder("\"")
        for (ch in s) {
            when {
                ch == '"' -> sb.append("\\\"")
                ch == '\\' -> sb.append("\\\\")
                ch == '\n' -> sb.append("\\n")
                ch == '\r' -> sb.append("\\r")
                ch == '\t' -> sb.append("\\t")
                ch < ' ' -> sb.append(String.format("\\u%04x", ch.code))
                else -> sb.append(ch)
            }
        }
        return sb.append('"').toString()
    }

    fun entryJson(
        id: String, nome: String, tipo: String, tamanho: Long, miniatura: String, url: String,
        formato: String? = null
    ): String {
        val m = LinkedHashMap<String, Any?>()
        m["id"] = id
        m["nome"] = nome
        m["tipo"] = tipo
        if (formato != null) m["formato"] = formato
        m["tamanho"] = tamanho
        m["miniatura"] = miniatura
        m["url"] = url
        return "  " + objectJson(m, "  ")
    }

    private fun valueJson(v: Any?): String {
        if (v == null || v == JSONObject.NULL) return "null"
        if (v is String) return q(v)
        if (v is Boolean || v is Number) return v.toString()
        return v.toString()
    }

    // Escreve o objeto no mesmo estilo do catálogo (2 espaços), sem escapar "/"
    fun objectJson(map: LinkedHashMap<String, Any?>, indent: String): String {
        val sb = StringBuilder("{\n")
        val inner = "$indent  "
        val keys = map.keys.toList()
        for ((idx, k) in keys.withIndex()) {
            sb.append(inner).append(q(k)).append(": ").append(valueJson(map[k]))
            if (idx < keys.size - 1) sb.append(",")
            sb.append("\n")
        }
        sb.append(indent).append("}")
        return sb.toString()
    }

    // Reconstrói um item mantendo a ordem das chaves e as chaves desconhecidas;
    // "formato" fica logo depois de "tipo"
    fun rebuild(
        old: JSONObject, nome: String, tipo: String, formato: String?,
        tamanho: Long, miniatura: String, url: String
    ): LinkedHashMap<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        val keys = old.keys()
        var formatPlaced = false
        while (keys.hasNext()) {
            val k = keys.next()
            when (k) {
                "formato" -> {}
                "nome" -> m[k] = nome
                "tipo" -> {
                    m[k] = tipo
                    if (formato != null) {
                        m["formato"] = formato
                        formatPlaced = true
                    }
                }
                "tamanho" -> m[k] = tamanho
                "miniatura" -> m[k] = miniatura
                "url" -> m[k] = url
                else -> m[k] = old.opt(k)
            }
        }
        if (formato != null && !formatPlaced) m["formato"] = formato
        return m
    }

    class Span(val start: Int, val end: Int)

    // Localiza o trecho de texto de cada item {...} da lista, sem interpretar o resto do arquivo
    fun itemSpans(text: String): List<Span> {
        val res = ArrayList<Span>()
        val n = text.length
        var i = 0
        var inStr = false
        var arrStart = -1
        while (i < n) {
            val c = text[i]
            if (inStr) {
                if (c == '\\') i++ else if (c == '"') inStr = false
            } else if (c == '"') {
                inStr = true
            } else if (c == '[') {
                arrStart = i
                break
            }
            i++
        }
        if (arrStart < 0) return res
        i = arrStart + 1
        var depth = 0
        var objStart = -1
        inStr = false
        while (i < n) {
            val c = text[i]
            if (inStr) {
                if (c == '\\') i++ else if (c == '"') inStr = false
            } else {
                when (c) {
                    '"' -> inStr = true
                    '{', '[' -> {
                        if (depth == 0 && c == '{') objStart = i
                        depth++
                    }
                    '}', ']' -> {
                        if (depth == 0) return res
                        depth--
                        if (depth == 0 && c == '}' && objStart >= 0) {
                            res.add(Span(objStart, i + 1))
                            objStart = -1
                        }
                    }
                }
            }
            i++
        }
        return res
    }

    fun findItemSpan(text: String, id: String, url: String): Span? {
        var byId: Span? = null
        for (sp in itemSpans(text)) {
            val o = try {
                JSONObject(text.substring(sp.start, sp.end))
            } catch (e: Exception) {
                continue
            }
            if (o.optString("id") == id) {
                if (o.optString("url") == url) return sp
                if (byId == null) byId = sp
            }
        }
        return byId
    }

    fun lineIndent(text: String, pos: Int): String {
        var ls = pos
        while (ls > 0 && text[ls - 1] != '\n') ls--
        val before = text.substring(ls, pos)
        return if (before.isBlank()) before else ""
    }

    // Remove o item e a vírgula que o acompanha, sem mexer no resto
    fun removeItem(text: String, sp: Span): String {
        val n = text.length
        var after = sp.end
        while (after < n && text[after].isWhitespace()) after++
        if (after < n && text[after] == ',') {
            var s0 = sp.start
            while (s0 > 0 && (text[s0 - 1] == ' ' || text[s0 - 1] == '\t')) s0--
            var e0 = after + 1
            while (e0 < n && (text[e0] == ' ' || text[e0] == '\t')) e0++
            if (e0 < n && text[e0] == '\r') e0++
            if (e0 < n && text[e0] == '\n') e0++
            return text.substring(0, s0) + text.substring(e0)
        }
        var b = sp.start - 1
        while (b >= 0 && text[b].isWhitespace()) b--
        if (b >= 0 && text[b] == ',') {
            return text.substring(0, b) + text.substring(sp.end)
        }
        var s0 = sp.start
        while (s0 > 0 && (text[s0 - 1] == ' ' || text[s0 - 1] == '\t')) s0--
        var e0 = sp.end
        while (e0 < n && (text[e0] == ' ' || text[e0] == '\t')) e0++
        if (e0 < n && text[e0] == '\r') e0++
        if (e0 < n && text[e0] == '\n') e0++
        return text.substring(0, s0) + text.substring(e0)
    }

    fun replaceItem(text: String, sp: Span, newObj: String): String =
        text.substring(0, sp.start) + newObj + text.substring(sp.end)

    fun verifyEdited(oldText: String, newText: String, targetOld: String) {
        val a = items(findArray(JSONTokener(oldText).nextValue()) ?: throw ApiException("Catálogo atual inválido"))
        val b = items(findArray(JSONTokener(newText).nextValue()) ?: throw ApiException("Validação do catálogo falhou"))
        val idx = a.indexOf(targetOld)
        if (a.size != b.size || idx < 0) throw ApiException("Validação do catálogo falhou")
        for (i in a.indices) {
            if (i != idx && a[i] != b[i]) throw ApiException("Validação do catálogo falhou (outros itens mudariam)")
        }
    }

    fun verifyRemoved(oldText: String, newText: String, targetOld: String) {
        val a = items(findArray(JSONTokener(oldText).nextValue()) ?: throw ApiException("Catálogo atual inválido"))
        val b = items(findArray(JSONTokener(newText).nextValue()) ?: throw ApiException("Validação do catálogo falhou"))
        val idx = a.indexOf(targetOld)
        if (idx < 0 || b.size != a.size - 1) throw ApiException("Validação do catálogo falhou")
        val rest = ArrayList(a)
        rest.removeAt(idx)
        if (rest != b) throw ApiException("Validação do catálogo falhou (outros itens mudariam)")
    }

    // Insere o novo item antes do último "]" sem mexer em mais nada do arquivo
    fun appendEntry(text: String, entry: String): String {
        val end = text.lastIndexOf(']')
        if (end < 0) throw ApiException("catalogo.json: não encontrei a lista de itens")
        val head = text.substring(0, end).trimEnd()
        val tail = text.substring(end)
        // se o arquivo já termina com "," (vírgula sobrando), reaproveita ela
        val sep = if (head.endsWith("[") || head.endsWith(",")) "\n" else ",\n"
        return head + sep + entry + "\n" + tail
    }

    private fun items(arr: JSONArray): List<String> {
        val r = ArrayList<String>()
        for (i in 0 until arr.length()) {
            if (!arr.isNull(i)) r.add(arr.get(i).toString())
        }
        return r
    }

    // Garante que os itens antigos continuam idênticos e que só 1 item foi acrescentado
    fun verifyAppended(oldText: String, newText: String) {
        val a = findArray(JSONTokener(oldText).nextValue())
            ?: throw ApiException("catalogo.json atual não tem uma lista de itens")
        val b = findArray(JSONTokener(newText).nextValue())
            ?: throw ApiException("Validação do novo catálogo falhou")
        val oldItems = items(a)
        val newItems = items(b)
        if (newItems.size != oldItems.size + 1) throw ApiException("Validação do novo catálogo falhou")
        for (i in oldItems.indices) {
            if (oldItems[i] != newItems[i]) {
                throw ApiException("Validação do novo catálogo falhou (itens antigos mudariam)")
            }
        }
    }
}
