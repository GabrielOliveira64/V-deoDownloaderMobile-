package com.vrdownloader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Gera uma thumb (jpg) a partir de uma imagem ou de um quadro de um vídeo. */
class ThumbMaker(
    private val a: AppCompatActivity,
    private val onResult: (Uri) -> Unit
) {
    private var source: Bitmap? = null
    private var videoUri: Uri? = null
    private var durationMs = 0L
    private var lastAutoName = ""
    private var frameJob: Job? = null

    private lateinit var fileText: TextView
    private lateinit var preview: ImageView
    private lateinit var seek: SeekBar
    private lateinit var seekLabel: TextView
    private lateinit var group: RadioGroup
    private lateinit var customRow: View
    private lateinit var customW: TextInputEditText
    private lateinit var customH: TextInputEditText
    private lateinit var nameEdit: TextInputEditText
    private lateinit var msg: TextView

    private val picker = a.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onPicked(uri)
    }

    fun show() {
        source = null
        videoUri = null
        durationMs = 0L
        lastAutoName = ""

        val view = LayoutInflater.from(a).inflate(R.layout.dialog_genthumb, null)
        fileText = view.findViewById(R.id.genFile)
        preview = view.findViewById(R.id.genPreview)
        seek = view.findViewById(R.id.genSeek)
        seekLabel = view.findViewById(R.id.genSeekLabel)
        group = view.findViewById(R.id.genGroup)
        customRow = view.findViewById(R.id.genCustomRow)
        customW = view.findViewById(R.id.genW)
        customH = view.findViewById(R.id.genH)
        nameEdit = view.findViewById(R.id.genName)
        msg = view.findViewById(R.id.genMsg)

        view.findViewById<MaterialButton>(R.id.genPick).setOnClickListener {
            picker.launch(arrayOf("image/*", "video/*"))
        }
        group.setOnCheckedChangeListener { _, id ->
            customRow.visibility = if (id == R.id.genCustom) View.VISIBLE else View.GONE
            refreshPreview()
        }
        customW.doAfterTextChanged { refreshPreview() }
        customH.doAfterTextChanged { refreshPreview() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                updateSeekLabel()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                loadFrame()
            }
        })

        val dialog = MaterialAlertDialogBuilder(a)
            .setTitle("Gerar thumb")
            .setView(view)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Gerar e usar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { generate(dialog) }
        }
        dialog.setOnDismissListener { frameJob?.cancel() }
        dialog.show()
    }

    // ---------- escolha da fonte ----------

    private fun onPicked(uri: Uri) {
        if (!::preview.isInitialized) return
        msg.text = ""
        val name = queryName(uri)
        fileText.text = name
        frameJob?.cancel()
        source = null

        if (isVideo(uri, name)) {
            videoUri = uri
            seek.visibility = View.VISIBLE
            seekLabel.visibility = View.VISIBLE
            updateSeekLabel()
            loadFrame()
        } else {
            videoUri = null
            seek.visibility = View.GONE
            seekLabel.visibility = View.GONE
            frameJob = a.lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) { decodeSampled(uri, 4096) }
                if (bmp == null) {
                    msg.text = "Não consegui abrir essa imagem."
                } else {
                    source = bmp
                    refreshPreview()
                }
            }
        }

        val auto = baseName(name) + "_thumb"
        val cur = nameEdit.text?.toString().orEmpty()
        if (cur.isEmpty() || cur == lastAutoName) nameEdit.setText(auto)
        lastAutoName = auto
    }

    private fun isVideo(uri: Uri, name: String): Boolean {
        val type = a.contentResolver.getType(uri) ?: ""
        val ext = name.substringAfterLast('.', "").lowercase()
        return type.startsWith("video") || ext in listOf("mp4", "mkv", "webm", "mov", "3gp")
    }

    private fun loadFrame() {
        val uri = videoUri ?: return
        val frac = seek.progress / 1000.0
        frameJob?.cancel()
        msg.text = "Carregando quadro…"
        frameJob = a.lifecycleScope.launch {
            val res: Pair<Bitmap?, Long> = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(a, uri)
                    val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    val t = (dur * frac).toLong() * 1000L
                    val bmp: Bitmap? = if (w > 4096 && h > 0) {
                        r.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 4096, 4096 * h / w)
                    } else {
                        r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }
                    Pair(bmp, dur)
                } catch (e: Exception) {
                    Pair(null, 0L)
                } finally {
                    r.release()
                }
            }
            durationMs = res.second
            updateSeekLabel()
            if (res.first == null) {
                msg.text = "Não consegui extrair um quadro desse vídeo."
            } else {
                msg.text = ""
                source = res.first
                refreshPreview()
            }
        }
    }

    private fun updateSeekLabel() {
        val ms = (durationMs * (seek.progress / 1000.0)).toLong()
        seekLabel.text = "Momento do vídeo: " + fmtTime(ms) + " (solte para atualizar)"
    }

    private fun fmtTime(ms: Long): String {
        val s = (ms / 1000).toInt()
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    // ---------- resolução e geração ----------

    private fun targetSize(): Pair<Int, Int>? {
        return when (group.checkedRadioButtonId) {
            R.id.gen320 -> Pair(320, 160)
            R.id.gen640 -> Pair(640, 320)
            R.id.gen1280 -> Pair(1280, 640)
            R.id.gen2048 -> Pair(2048, 1024)
            R.id.genCustom -> {
                val w = customW.text?.toString()?.toIntOrNull() ?: 0
                val h = customH.text?.toString()?.toIntOrNull() ?: 0
                if (w in 16..4096 && h in 16..4096) Pair(w, h) else null
            }
            else -> null
        }
    }

    private fun refreshPreview() {
        if (!::preview.isInitialized) return
        val src = source ?: return
        val t = targetSize() ?: return
        val pw = minOf(t.first, 800)
        val ph = maxOf(1, pw * t.second / t.first)
        preview.setImageBitmap(ImageUtil.cropScale(src, pw, ph))
    }

    private fun generate(dialog: AlertDialog) {
        val src = source
        if (src == null) {
            msg.text = "Escolha uma imagem ou vídeo primeiro."
            return
        }
        val t = targetSize()
        if (t == null) {
            msg.text = "Resolução personalizada inválida (use de 16 a 4096)."
            return
        }
        val name = nameEdit.text?.toString().orEmpty().trim()
            .replace(Regex("""\.jpe?g$""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""[\\/:*?"<>|]"""), "")
            .replace(Regex("""\s+"""), "_")
        if (name.isEmpty()) {
            msg.text = "Digite o nome da thumb."
            return
        }
        try {
            val out = ImageUtil.cropScale(src, t.first, t.second)
            val uri = ImageUtil.saveJpeg(a, out, "$name.jpg")
            dialog.dismiss()
            onResult(uri)
        } catch (e: Exception) {
            msg.text = "Erro ao gerar: " + e.message
        }
    }

    // ---------- utilitários ----------

    private fun queryName(uri: Uri): String {
        a.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "arquivo"
        }
        return uri.lastPathSegment ?: "arquivo"
    }

    private fun baseName(name: String): String =
        if (name.contains('.')) name.substringBeforeLast('.') else name

    private fun decodeSampled(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > maxSide || o.outHeight / s > maxSide) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Exception) {
            null
        }
    }
}
